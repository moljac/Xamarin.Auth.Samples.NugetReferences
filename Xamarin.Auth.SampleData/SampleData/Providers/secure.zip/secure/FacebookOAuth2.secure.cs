﻿using System;
using System.Threading.Tasks;

namespace Xamarin.Auth.SampleData
{
	public partial class FacebookOAuth2 
	{
		partial void SetPrivateSensitiveData()
		{
			HowToMarkDown = 
@"
	https://developers.facebook.com/apps/
	Test Xama­r­i­n­.­Auth Apptype = A
		1609587185978295
	Test Xama­r­i­n­.­Auth Apptype = iOS
		418964834940058
	Test Xama­r­i­n­.­Auth Apptype = www
		523432231128758
		Settings 
			Advanced
				https://developers.facebook.com/apps/523432231128758/settings/advanced/
			Valid OAuth redirect URIs
				https://xamarin.com
				https://www.xamarin.com
			using URI not listed here will cause:
				Error:
				Given URL is not allowed by the Application configuration.: 
				One or more of the given URLs is not allowed by the App's settings. 
				It must match the Website URL or Canvas URL, or the domain must be a 
				subdomain of one of the App's domains.
";
			Description = "Facebook OAuth2";
			OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "523432231128758";
			OAuth2_Scope = ""; // "", "basic", "email",
			OAuth_UriAuthorization = new Uri("https://m.facebook.com/dialog/oauth/");
			OAuth_UriCallbackAKARedirect = new Uri("https://xamarin.com");
			AllowCancel = true;
						
			return;
		}

	}
}

