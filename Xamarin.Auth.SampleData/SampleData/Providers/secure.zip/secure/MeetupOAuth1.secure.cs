﻿using System;
using System.Threading.Tasks;

namespace Xamarin.Auth.SampleData
{
	public partial class MeetupOAuth1 
	{
		partial void SetPrivateSensitiveData()
		{
			HowToMarkDown = 
			@"
			";
			Description = "Meetup OAuth1";
			OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "d37uu256d2tr3sn75h63vec8p7";
			OAuth1_SecretKey_ConsumerSecret_APISecret = "j52mflldno3r863e76o007okgp";
			OAuth1_UriRequestToken = new Uri("https://api.meetup.com/oauth/request");
			OAuth_UriAuthorization = new Uri("https://secure.meetup.com/authorize");
			OAuth_UriAccessToken = new Uri("https://api.meetup.com/oauth/access");
			OAuth_UriCallbackAKARedirect = new Uri("http://xamarin.com");
			AllowCancel = true;
						
			return;
		}

	}
}

