﻿using System;
using Xamarin.Auth.Helpers;

namespace Xamarin.Auth.SampleData
{
	public partial class LinkedInOAuth2
	{
		partial void SetPrivateSensitiveData()
		{
			HowToMarkDown = 
@"
	https://developer.linkedin.com/
	https://www.linkedin.com/developer/apps/3679273/auth
	
	Authentication Keys
		Client ID:		7708jdzn99hom0
		Client Secret:	ktFMFnqyw8b5LGMp
	Default Application Permissions
		r_basicprofile	r_contactinfo	r_emailaddress
		r_fullprofile	r_network	rw_company_admin
		rw_groups	rw_nus	w_messages
		w_share

	OAuth 2.0
		Authorized Redirect URLs: 
			https://xamarin.com 		
			http://xamarin.com 		
			https://xamarin.com/
			http://xamarin.com/

	OAuth 1.0a
		Default 'Accept' Redirect URL:
			http://xamarin.com
		Default 'Cancel' Redirect URL:
			http://xamarin.com

	Redirect Uri must EXACTLY match

";
			Description = "LinkedIn OAuth2";
			OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "7708jdzn99hom0";
			OAuth2_Scope = "r_basicprofile";
			OAuth_UriCallbackAKARedirect = new Uri("https://xamarin.com");
			OAuth_UriAuthorization = 
						new Uri
							(
								"https://www.linkedin.com/uas/oauth2/authorization?"
								+
								"response_type=code"
								+ "&" +
								"client_id=" + OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer
								+ "&" +
								"scope=" + Uri.EscapeDataString(OAuth2_Scope)
								+ "&" +
								"redirect_uri=" + Uri.EscapeDataString(OAuth_UriCallbackAKARedirect.ToString())
							);
			AllowCancel = true;

			return;
		}
	}
}

