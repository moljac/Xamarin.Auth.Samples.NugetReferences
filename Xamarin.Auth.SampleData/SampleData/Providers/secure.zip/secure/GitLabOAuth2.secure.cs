﻿using System;
using System.Threading.Tasks;

namespace Xamarin.Auth.SampleData
{
	public partial class GitLabOAuth2
    {
		partial void SetPrivateSensitiveData()
		{
            HowToMarkDown =
            @"
http://doc.gitlab.com/ce/integration/oauth_provider.html

https://gitlab.com/oauth/authorize

			";
            Description = "Gitlab OAuth2";
            OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "6c5a6f7e012223578684b38465a2d0a5622e190a9c33dcbcb9ac80c7be7b901f";
            OAuth2_Scope = "api"; // 
            OAuth_UriAuthorization = new Uri("https://gitlab.com/oauth/authorize");
            OAuth_UriCallbackAKARedirect = new Uri("https://xamarin.com");
            AllowCancel = true;

            return;
        }

    }
}

