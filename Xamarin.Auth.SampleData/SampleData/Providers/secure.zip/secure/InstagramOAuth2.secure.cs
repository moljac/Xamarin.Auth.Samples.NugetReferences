﻿using System;
using Xamarin.Auth.Helpers;

namespace Xamarin.Auth.SampleData
{
	public partial class InstagramOAuth2
	{
		partial void SetPrivateSensitiveData()
		{
			HowToMarkDown = 
@"

	CLIENT INFO
	CLIENT ID			5a0590cb807045d68cbb2459ab336869
	WEBSITE URL			http://xamarin.com
	REDIRECT URI		http://xamarin.com/
	SUPPORT EMAIL		None
";
			Description = "Instagram OAuth2";
			OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "5a0590cb807045d68cbb2459ab336869";
			OAuth2_Scope = "basic"; // "", "basic", "email",
			OAuth_UriAuthorization = new Uri("https://api.instagram.com/oauth/authorize/");
			OAuth_UriCallbackAKARedirect = new Uri("http://xamarin.com");
			AllowCancel = true;
						
			return;
		}
	}
}

