﻿using System;
using System.Threading.Tasks;

namespace Xamarin.Auth.SampleData
{
	public partial class MeetupOAuth2 
	{
		partial void SetPrivateSensitiveData()
		{
			HowToMarkDown = 
@"
";
			Description = "Meetup OAuth2";
			OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "d37uu256d2tr3sn75h63vec8p7";
			OAuth2_Scope = ""; // "", "basic", "email",
			OAuth_UriAuthorization = new Uri("https://secure.meetup.com/oauth2/authorize");
			OAuth_UriCallbackAKARedirect = new Uri("https://xamarin.com");
			AllowCancel = true;
						
			return;
		}

	}
}

