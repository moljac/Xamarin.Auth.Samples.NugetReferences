﻿using System;
using Xamarin.Auth.Helpers;

namespace Xamarin.Auth.SampleData
{
	public partial class GithubOAuth2 
	{
		partial void SetPrivateSensitiveData()
		{
			HowToMarkDown = 
			@"
				https://github.com/settings/applications
				https://developer.github.com/v3/oauth/#scopes
				https://github.com/settings/developers
				5b5c2d2d76e2fd9a804b
			";
			Description = "Github OAuth2";
			OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "5b5c2d2d76e2fd9a804b";
			OAuth_SecretKey_ConsumerSecret_APISecret = "93e7f486b09bd1af4c38913cfaacbf8a384a50d2";
			OAuth_UriAuthorization=new Uri("https://github.com/login/oauth/authorize");
			OAuth_UriCallbackAKARedirect = new Uri("http://xamarin.com");
			OAuth_UriAccessToken = new Uri("https://github.com/login/oauth/access_token");
			AllowCancel = true;

			return;
		}
	}
}

